<html>
  <head>
  </head>
  <body>
    <p>
      <?php
        $items = 3;
        
        if($items > 5) {
          echo "You get a 10% discount!";
        }
       else{
           echo "You get a 5% discount!";
       }
        
      ?>
    </p>
  </body>
</html>