<html>
  <head>
  </head>
  <body>
    <p>
      <?php
        // Write your if/elseif/else statement here!
        if(5>6){
            echo "the condition is true";
        } 
        else{
            echo '"the condition is false"';
        }
      ?>
    </p>
  </body>
</html>