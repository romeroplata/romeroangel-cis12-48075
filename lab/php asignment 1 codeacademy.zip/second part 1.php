<html>
  <head>
    <title>Comparing Numbers</title>
  </head>
  <body>
    <p>
      <?php
        10==10;
      ?>
    </p>
  </body>
</html>