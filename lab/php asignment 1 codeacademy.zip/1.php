<!DOCTYPE html>
<html>
	<head>
	</head>
	<body>
        <p>
          <?php
       echo"cuando"." "."vamos a trabajar";   
          ?>
        </p>
	</body>
</html>