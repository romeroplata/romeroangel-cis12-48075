<html>
  <head>
  </head>
  <body>
    <p>
      <?php
        $items = 5;     // Set this to a number greater than 5!
        
        if($items == 5) {
          echo "You get a 10% discount!";
        }
      ?>
    </p>
  </body>
</html>