<!DOCTYPE html>
<html>
	<head>
	</head>
	<body>
	    <p>
	      <?php
$myName="angel";	      
	      ?>
	    </p>
    </body>
</html>